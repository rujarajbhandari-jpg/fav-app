const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

// In-memory storage
let movies = [];
let idCounter = 1;

// GET all movies
app.get("/movies", (req, res) => {
  res.json(movies);
});

// POST add movie
app.post("/movies", (req, res) => {
  const newMovie = { id: idCounter++, ...req.body };
  movies.push(newMovie);
  res.json(newMovie);
});

// PUT update movie
app.put("/movies/:id", (req, res) => {
  const id = parseInt(req.params.id);
  movies = movies.map(movie =>
    movie.id === id ? { ...movie, ...req.body } : movie
  );
  res.json({ message: "Updated" });
});

// DELETE movie
app.delete("/movies/:id", (req, res) => {
  const id = parseInt(req.params.id);
  movies = movies.filter(movie => movie.id !== id);
  res.json({ message: "Deleted" });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
