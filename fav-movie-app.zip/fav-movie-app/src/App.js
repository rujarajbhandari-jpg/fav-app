import React, { useEffect, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/movies";

function App() {
  const [movies, setMovies] = useState([]);
  const [form, setForm] = useState({
    name: "",
    genre: "",
    releaseDate: "",
    studio: "",
    score: ""
  });
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    fetchMovies();
  }, []);

  // GET
  const fetchMovies = async () => {
    const res = await fetch(API);
    const data = await res.json();
    setMovies(data);
  };

  // Handle input
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // POST / PUT
  const handleSubmit = async () => {
    if (editingId) {
      await fetch(`${API}/${editingId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
    } else {
      await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
    }

    setForm({
      name: "",
      genre: "",
      releaseDate: "",
      studio: "",
      score: ""
    });
    setEditingId(null);
    setShowForm(false);
    fetchMovies();
  };

  // EDIT
  const handleEdit = (movie) => {
    setForm(movie);
    setEditingId(movie.id);
    setShowForm(true);
  };

  // DELETE
  const handleDelete = async (id) => {
    await fetch(`${API}/${id}`, {
      method: "DELETE"
    });
    fetchMovies();
  };

  return (
    <div className="container">
      <div className="header">
       <h2>Movie List</h2>
        <div className="container2">
       <button className="add-btn" onClick={() => setShowForm(!showForm)}>
          Add New Movie
        </button></div>
      </div>

      {showForm && (
        <div className="form">
          <input name="name" placeholder="Movie Name" value={form.name} onChange={handleChange} />
          <input name="genre" placeholder="Genre" value={form.genre} onChange={handleChange} />
          <input name="releaseDate" placeholder="Release Date" value={form.releaseDate} onChange={handleChange} />
          <input name="studio" placeholder="Studio" value={form.studio} onChange={handleChange} />
          <input name="score" placeholder="Score" value={form.score} onChange={handleChange} />

          <button className="add-btn" onClick={handleSubmit}>
            {editingId ? "Update" : "Add"}
          </button>
        </div>
      )}

      <table>
        <thead>
          <tr>
            <th>Movie Name</th>
            <th>Genre</th>
            <th>Release Date</th>
            <th>Studio</th>
            <th>Score</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {movies.map((movie) => (
            <tr key={movie.id}>
              <td>{movie.name}</td>
              <td>{movie.genre}</td>
              <td>{movie.releaseDate}</td>
              <td>{movie.studio}</td>
              <td>{movie.score}</td>
              <td>
                <button className="edit-btn" onClick={() => handleEdit(movie)}>
                  Edit
                </button>
                <button className="delete-btn" onClick={() => handleDelete(movie.id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
